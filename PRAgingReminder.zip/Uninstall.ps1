﻿<#
.SYNOPSIS
    Removes PR Aging Reminder from this machine.
#>

param(
    [switch]$KeepConfig  # Preserve config.json (useful when reinstalling)
)

$taskName   = "PRAgingReminder"
$configPath = Join-Path $PSScriptRoot "config.json"

Write-Host ""
Write-Host "Uninstalling PR Aging Reminder..." -ForegroundColor Yellow

# Remove scheduled task
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    Write-Host "  Removed scheduled task '$taskName'" -ForegroundColor Green
} else {
    Write-Host "  Scheduled task '$taskName' not found (already removed)" -ForegroundColor Gray
}

# Remove config
if (-not $KeepConfig -and (Test-Path $configPath)) {
    Remove-Item $configPath -Force
    Write-Host "  Deleted config.json" -ForegroundColor Green
} elseif ($KeepConfig) {
    Write-Host "  Kept config.json (-KeepConfig specified)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "Done. PR Aging Reminder has been uninstalled." -ForegroundColor Green
Write-Host "To reinstall, run Install.ps1 again." -ForegroundColor Gray
Write-Host ""
