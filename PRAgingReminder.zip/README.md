# PR Aging Reminder

Get daily Microsoft Teams notifications about your open Azure DevOps pull requests, with urgency colour-coding based on your team's PR aging policy.

---

## What it does

- Fetches all **active PRs you created** in your Azure DevOps project
- Calculates days remaining under your team's aging policy (default: 14 days)
- Posts a colour-coded **Adaptive Card** to your Teams channel via a Workflows webhook
- Runs automatically **every weekday** at a time you choose

| Indicator | Meaning |
|-----------|---------|
| 🟢 | More than 5 days left |
| 🟡 | 3–5 days left — take action soon |
| 🟠 | 1–2 days left — critical |
| 🔴 | Overdue — past the policy limit |

---

## Requirements

- Windows 10 / Windows 11 (PowerShell 5.1 or later — built in)
- Access to an Azure DevOps organisation
- A Microsoft Teams channel where you have permission to add Workflows

---

## Installation

### 1. Download and extract

Download `PRAgingReminder.zip` and extract it to any permanent folder, e.g.  
`C:\Tools\PRAgingReminder\`

> **Important:** Do not move the folder after installation — the scheduled task points to this location.

### 2. Create a Teams Workflows webhook

1. Open the Teams channel where you want reminders
2. Click **+** next to the channel name → **Workflows**
3. Search for **"Post to a channel when a webhook request is received"**
4. Follow the prompts → **Copy the webhook URL**

> The older "Incoming Webhook" connector is deprecated. Use Workflows instead.

### 3. Create an Azure DevOps PAT

1. Go to: `https://dev.azure.com/{YOUR_ORG}/_usersSettings/tokens`
2. Click **New Token**
3. Set scope: **Code → Read**
4. Copy the token — you will need it during setup

### 4. Run the setup wizard

Open PowerShell in the extracted folder and run:

```powershell
.\Install.ps1
```

The wizard will ask for:
- Your Azure DevOps **organisation name** and **project name**
- Your **email address** (the one your PRs are created under)
- Your **Personal Access Token** (stored encrypted — never saved in plain text)
- The **Teams webhook URL** from Step 2
- Your team's **PR aging limit** in days (default: 14)
- The **daily reminder time** (default: 09:00)

It tests every connection as you go and sends a test message to your Teams channel.

---

## Usage

### Run on demand

```powershell
# Send reminder now
.\PR-Reminder.ps1

# Preview without sending to Teams
.\PR-Reminder.ps1 -DryRun

# Trigger via Task Scheduler
Start-ScheduledTask -TaskName PRAgingReminder
```

### Update settings

```powershell
.\Install.ps1 -Reconfigure
```

### Uninstall

```powershell
.\Uninstall.ps1
```

---

## Security

- Your PAT is encrypted using **Windows DPAPI** before being stored in `config.json`
- The encrypted value can only be decrypted by **you, on this machine**
- No credentials are stored in plain text, environment variables, or task XML

---

## Files

| File | Description |
|------|-------------|
| `Install.ps1` | Setup wizard — run once to configure |
| `PR-Reminder.ps1` | Core engine — fetches PRs and sends Teams card |
| `Uninstall.ps1` | Removes the scheduled task and config |
| `config.json` | Created by Install.ps1 — do not edit manually |
| `README.md` | This file |

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| No Teams message, task exits with code 1 | Re-run `.\Install.ps1 -Reconfigure` — PAT may have expired |
| "config.json not found" | Run `.\Install.ps1` first |
| 401 from Azure DevOps | Create a new PAT with **Code > Read** scope |
| Webhook returns 400/403 | Recreate the Workflows webhook in Teams |
| "No active PRs found" | Correct — no message is sent when you have no open PRs |
