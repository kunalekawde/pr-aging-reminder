﻿<#
.SYNOPSIS
    PR Aging Reminder - Setup Wizard (interactive or non-interactive).

.DESCRIPTION
    Configures PR aging reminders via Teams and/or Email.
    Run interactively (no params) for a guided wizard.
    Pass all params for a silent install (e.g. from the Teams app setup command).

.EXAMPLE
    .\Install.ps1
    .\Install.ps1 -Reconfigure
    .\Install.ps1 -OrgName "msazuredev" -Project "AzureForOperators" -UserEmail "you@company.com" `
                  -PAT "your-pat" -TeamsWebhookUrl "https://..." -AgingDays 14 -NonInteractive
#>

param(
    [switch]$Reconfigure,
    [switch]$NonInteractive,
    [string]$OrgName         = "",
    [string]$Project         = "",
    [string]$UserEmail       = "",
    [string]$PAT             = "",
    [string]$TeamsWebhookUrl = "",
    [int]$AgingDays          = 0,
    [string]$ScheduleTime    = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$scriptDir  = $PSScriptRoot
$configPath = Join-Path $scriptDir "config.json"
$taskName   = "PRAgingReminder"

# ── Helpers ───────────────────────────────────────────────────────────────────
function Banner {
    Clear-Host
    Write-Host ""
    Write-Host "  +---------------------------------------------------------+" -ForegroundColor Cyan
    Write-Host "  |        PR Aging Reminder  -  Setup Wizard               |" -ForegroundColor Cyan
    Write-Host "  |  Teams + Email notifications for your aging PRs         |" -ForegroundColor Cyan
    Write-Host "  +---------------------------------------------------------+" -ForegroundColor Cyan
    Write-Host ""
}

function Coalesce($a, $b) { if ($null -ne $a -and "$a" -ne "") { $a } else { $b } }

function Ask([string]$prompt, [string]$default = "", [switch]$Secret) {
    $display = if ($default) { "$prompt [$default]" } else { $prompt }
    Write-Host "  $display" -ForegroundColor Yellow -NoNewline
    Write-Host ": " -NoNewline
    if ($Secret) {
        $secure = Read-Host -AsSecureString
        return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
            [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
        )
    }
    $val = Read-Host
    if ($val -eq "" -and $default) { return $default } else { return $val }
}

function YesNo([string]$prompt, [string]$default = "y") {
    $val = Ask "$prompt (y/n)" $default
    return $val -eq "y"
}

function Ok   ([string]$msg) { Write-Host "  [OK]   $msg" -ForegroundColor Green }
function Fail ([string]$msg) { Write-Host "  [FAIL] $msg" -ForegroundColor Red }
function Info ([string]$msg) { Write-Host "  [INFO] $msg" -ForegroundColor Cyan }
function Step ([string]$msg) { Write-Host "`n--- $msg ---" -ForegroundColor White }

# ── Load existing config ──────────────────────────────────────────────────────
$e = if (Test-Path $configPath) {
    Get-Content $configPath -Raw | ConvertFrom-Json
} else {
    [PSCustomObject]@{
        AzureDevOps   = [PSCustomObject]@{ OrgName=""; Project=""; UserEmail=""; EncryptedPAT="" }
        Notifications = [PSCustomObject]@{ TeamsWebhookUrl="" }
        Policy        = [PSCustomObject]@{ AgingDays="14"; ScheduleTime="11:00" }
    }
}

# Migrate old config schema: Teams -> Notifications
if (-not ($e.PSObject.Properties.Name -contains 'Notifications')) {
    $oldUrl = if ($e.PSObject.Properties.Name -contains 'Teams') { $e.Teams.WebhookUrl } else { "" }
    $e | Add-Member -NotePropertyName 'Notifications' -NotePropertyValue (
        [PSCustomObject]@{ TeamsWebhookUrl=$oldUrl }
    )
}

# ── Non-interactive fast-path ─────────────────────────────────────────────────
if ($NonInteractive) {
    if (-not $OrgName -or -not $Project -or -not $PAT) {
        Write-Error "-OrgName, -Project, and -PAT are required for non-interactive install."
        exit 1
    }
    if (-not $TeamsWebhookUrl) {
        Write-Error "-TeamsWebhookUrl is required for non-interactive install."
        exit 1
    }

    Write-Host "PR Aging Reminder - Silent Install" -ForegroundColor Cyan
    Write-Host "Validating Azure DevOps connection..." -NoNewline

    $authHdr = @{ Authorization = "Basic $([Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT")))" }
    try {
        $conn = Invoke-RestMethod "https://dev.azure.com/$OrgName/_apis/connectiondata" -Headers $authHdr -ErrorAction Stop
        Write-Host " OK ($($conn.authenticatedUser.providerDisplayName))" -ForegroundColor Green
    } catch {
        Write-Host " FAILED" -ForegroundColor Red
        Write-Error "PAT validation failed: $_"
        exit 1
    }

    $encPAT     = ($PAT | ConvertTo-SecureString -AsPlainText -Force) | ConvertFrom-SecureString
    $agDays     = if ($AgingDays   -gt 0)               { $AgingDays }    else { 14 }
    $schedTime  = if ($ScheduleTime -match '^\d{2}:\d{2}$') { $ScheduleTime } else { "11:00" }
    $userEmail  = if ($UserEmail)  { $UserEmail }  else { "$env:USERNAME@$env:USERDNSDOMAIN" }

    $config = [ordered]@{
        AzureDevOps   = [ordered]@{ OrgName=$OrgName; Project=$Project; UserEmail=$userEmail; EncryptedPAT=$encPAT }
        Notifications = [ordered]@{ TeamsWebhookUrl=$TeamsWebhookUrl }
        Policy = [ordered]@{ AgingDays=$agDays; ScheduleTime=$schedTime }
        _meta  = [ordered]@{ InstalledBy=$env:USERNAME; InstalledOn=(Get-Date -Format "yyyy-MM-dd HH:mm:ss"); Version="2.0" }
    }
    $config | ConvertTo-Json -Depth 5 | Set-Content $configPath -Encoding UTF8

    # Register scheduled task
    $scriptPath = Join-Path $scriptDir "PR-Reminder.ps1"
    $argument   = "-NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File ""$scriptPath"""
    $trigger    = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday,Tuesday,Wednesday,Thursday,Friday -At $schedTime
    $action     = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $argument
    $settings   = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
        -StartWhenAvailable -RunOnlyIfNetworkAvailable `
        -MultipleInstances IgnoreNew
    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    }
    Register-ScheduledTask -TaskName $taskName -Trigger $trigger -Action $action -Settings $settings `
        -RunLevel Limited -Description "PR Aging Reminder" | Out-Null

    Write-Host "Config saved and scheduled task registered (Mon-Fri at $schedTime)" -ForegroundColor Green
    Write-Host "Running first reminder..." -ForegroundColor Cyan
    & $scriptPath
    exit 0
}


if ((Test-Path $configPath) -and -not $Reconfigure) {
    Banner
    Write-Host "  PR Aging Reminder is already configured." -ForegroundColor Green
    Write-Host "  Run  .\Install.ps1 -Reconfigure  to update settings." -ForegroundColor Gray
    Write-Host ""
    if (-not (YesNo "Re-run setup wizard now?" "n")) { exit 0 }
}

Banner

# ══ STEP 1: Azure DevOps ══════════════════════════════════════════════════════
Step "Step 1 of 5 : Azure DevOps Connection"
Write-Host ""
Info "Your org and project are in the Azure DevOps URL:"
Info "  https://dev.azure.com/{ORG}/{PROJECT}"
Write-Host ""

$orgName = Ask "Organization name"       (Coalesce $e.AzureDevOps.OrgName "")
$project = Ask "Project name"            (Coalesce $e.AzureDevOps.Project "")
$email   = Ask "Your email (PR creator)" (Coalesce $e.AzureDevOps.UserEmail "")

Write-Host ""
Info "Create a PAT at: https://dev.azure.com/$orgName/_usersSettings/tokens"
Info "Required scope : Code > Read"
Write-Host ""

$patPlain = Ask "Personal Access Token" -Secret

Write-Host ""
Write-Host "  Testing Azure DevOps connection..." -NoNewline
try {
    $authHdr  = @{ Authorization = "Basic $([Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$patPlain")))" }
    $conn     = Invoke-RestMethod "https://dev.azure.com/$orgName/_apis/connectiondata" -Headers $authHdr -ErrorAction Stop
    $dispName = $conn.authenticatedUser.providerDisplayName
    Write-Host " OK" -ForegroundColor Green
    Ok "Authenticated as: $dispName"

    $repos = Invoke-RestMethod "https://dev.azure.com/$orgName/$([Uri]::EscapeUriString($project))/_apis/git/repositories?api-version=7.0" -Headers $authHdr -ErrorAction Stop
    Ok "Project '$project' found ($($repos.count) repo(s))"
} catch {
    Write-Host " FAILED" -ForegroundColor Red
    Fail "Error: $_"
    Fail "Fix org name, project name, or PAT scope (Code > Read), then re-run."
    exit 1
}

# ══ STEP 2: Teams Webhook (optional) ══════════════════════════════════════════
Step "Step 2 of 5 : Teams Notification (optional)"
Write-Host ""
Info "Uses the classic Incoming Webhook connector."
Info "In Teams: channel (...) -> Connectors -> Incoming Webhook -> Configure -> Copy URL"
Write-Host ""

$teamsUrl = ""
if (YesNo "Enable Teams notifications?") {
    $teamsUrl = Ask "Incoming Webhook URL" (Coalesce $e.Notifications.TeamsWebhookUrl "")

    Write-Host ""
    Write-Host "  Testing Teams webhook..." -NoNewline
    $pingJson = '{"text":"PR Aging Reminder - setup test. Your Teams notifications are now configured."}'
    $pingBytes = [System.Text.Encoding]::UTF8.GetBytes($pingJson)
    try {
        $resp = Invoke-RestMethod -Uri $teamsUrl -Method Post -Body $pingBytes `
            -ContentType "application/json; charset=utf-8" -ErrorAction Stop
        Write-Host " OK" -ForegroundColor Green
        Ok "Test message sent (response: $resp). Check your channel."
    } catch {
        Write-Host " FAILED" -ForegroundColor Red
        Fail "Webhook test failed: $_"
        $continue = YesNo "Continue anyway and save this URL?" "n"
        if (-not $continue) { $teamsUrl = "" }
    }
} else {
    Info "Skipping Teams. You can add it later with .\Install.ps1 -Reconfigure"
}

# Validate Teams webhook required
if (-not $teamsUrl) {
    Fail "Teams Incoming Webhook URL is required."
    Fail "Re-run Install.ps1 and provide a webhook URL."
    exit 1
}

# ══ STEP 3: Policy ════════════════════════════════════════════════════════════
Step "Step 3 of 4 : PR Aging Policy"
Write-Host ""
$agingDays = Ask "Maximum PR age before overdue (days)" (Coalesce $e.Policy.AgingDays "14")
while ($agingDays -notmatch '^\d+$' -or [int]$agingDays -lt 1) {
    Fail "Enter a positive integer."
    $agingDays = Ask "Maximum PR age before overdue (days)" "14"
}

# ══ STEP 5: Schedule ══════════════════════════════════════════════════════════
Step "Step 4 of 4 : Reminder Schedule"
Write-Host ""
Info "Runs automatically every weekday at the time you choose."
$scheduleTime = Ask "Daily reminder time (HH:MM, 24-hour)" (Coalesce $e.Policy.ScheduleTime "11:00")
while ($scheduleTime -notmatch '^\d{2}:\d{2}$') {
    Fail "Use HH:MM format (e.g. 09:00)"
    $scheduleTime = Ask "Daily reminder time" "11:00"
}

# ══ Save Config ════════════════════════════════════════════════════════════════
Step "Saving configuration"

$encPAT = ($patPlain | ConvertTo-SecureString -AsPlainText -Force) | ConvertFrom-SecureString

$config = [ordered]@{
    AzureDevOps = [ordered]@{
        OrgName      = $orgName
        Project      = $project
        UserEmail    = $email
        EncryptedPAT = $encPAT
    }
    Notifications = [ordered]@{
        TeamsWebhookUrl = $teamsUrl
    }
    Policy = [ordered]@{
        AgingDays    = [int]$agingDays
        ScheduleTime = $scheduleTime
    }
    _meta = [ordered]@{
        InstalledBy = $env:USERNAME
        InstalledOn = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        Version     = "2.0"
    }
}

$config | ConvertTo-Json -Depth 5 | Set-Content $configPath -Encoding UTF8
Ok "Config saved: $configPath"
Ok "PAT encrypted with Windows DPAPI (readable only by $env:USERNAME on this machine)"

$channels = @()
if ($teamsUrl) { $channels += "Teams" }
Ok "Notification channel: $($channels -join ' + ')"

# ══ Register Scheduled Task ════════════════════════════════════════════════════
Step "Registering scheduled task"

$scriptPath = Join-Path $scriptDir "PR-Reminder.ps1"
$argument   = "-NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File ""$scriptPath"""

$trigger  = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday,Tuesday,Wednesday,Thursday,Friday -At $scheduleTime
$action   = New-ScheduledTaskAction  -Execute "powershell.exe" -Argument $argument
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
    -StartWhenAvailable -RunOnlyIfNetworkAvailable `
    -MultipleInstances IgnoreNew

if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    Info "Removed previous scheduled task"
}
Register-ScheduledTask -TaskName $taskName -Trigger $trigger -Action $action `
    -Settings $settings -RunLevel Limited `
    -Description "PR Aging Reminder - daily Teams + Email notifications" | Out-Null
Ok "Scheduled task '$taskName' registered (Mon-Fri at $scheduleTime)"

# ══ First run ══════════════════════════════════════════════════════════════════
Step "Sending first reminder"
Write-Host ""
Write-Host "  Running PR-Reminder.ps1 now..." -NoNewline
try {
    & $scriptPath -ErrorAction Stop
    Write-Host ""
} catch {
    Write-Host " Warning: $_" -ForegroundColor Yellow
    Info "Run manually to retry:  .\PR-Reminder.ps1"
}

# ══ Done ══════════════════════════════════════════════════════════════════════
Write-Host ""
$chLine  = "  Channels : $($channels -join ' + ')"
$schLine = "  Schedule : Mon-Fri at $scheduleTime"
Write-Host "  +----------------------------------------------------------+" -ForegroundColor Green
Write-Host "  |  Setup complete!                                         |" -ForegroundColor Green
Write-Host "  |                                                          |" -ForegroundColor Green
Write-Host ("  |  " + $chLine.PadRight(56) + "|") -ForegroundColor Green
Write-Host ("  |  " + $schLine.PadRight(56) + "|") -ForegroundColor Green
Write-Host "  |                                                          |" -ForegroundColor Green
Write-Host "  |  Run on demand : .\PR-Reminder.ps1                      |" -ForegroundColor Green
Write-Host "  |  Reconfigure   : .\Install.ps1 -Reconfigure             |" -ForegroundColor Green
Write-Host "  |  Uninstall     : .\Uninstall.ps1                        |" -ForegroundColor Green
Write-Host "  +----------------------------------------------------------+" -ForegroundColor Green
Write-Host ""
