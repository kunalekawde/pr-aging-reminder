﻿<#
.SYNOPSIS
    PR Aging Reminder - Core engine.
    Fetches active PRs and delivers notifications via Teams and/or Email.

.PARAMETER DryRun
    Print PR table and card JSON without sending any notifications.
#>

[CmdletBinding()]
param([switch]$DryRun)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Load config ───────────────────────────────────────────────────────────────
$configPath = Join-Path $PSScriptRoot "config.json"
if (-not (Test-Path $configPath)) {
    Write-Error "config.json not found. Please run Install.ps1 first."
    exit 1
}
$cfg = Get-Content $configPath -Raw | ConvertFrom-Json

$Org         = $cfg.AzureDevOps.OrgName
$Project     = $cfg.AzureDevOps.Project
$Email       = $cfg.AzureDevOps.UserEmail
$AgingDays   = [int]$cfg.Policy.AgingDays
$WebhookUrl  = $cfg.Notifications.TeamsWebhookUrl

# Decrypt PAT
try {
    $PAT = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
        [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR(
            ($cfg.AzureDevOps.EncryptedPAT | ConvertTo-SecureString)
        )
    )
} catch {
    Write-Error "Failed to decrypt PAT. Re-run Install.ps1 to re-enter credentials."
    exit 1
}

# ── Azure DevOps helpers ──────────────────────────────────────────────────────
$authHeader = @{
    Authorization  = "Basic $([Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT")))"
    "Content-Type" = "application/json"
}
function Invoke-ADO([string]$Uri) {
    Invoke-RestMethod -Uri $Uri -Headers $authHeader -Method Get -ErrorAction Stop
}

# ── Resolve user + fetch PRs ──────────────────────────────────────────────────
$userId = $null
try {
    $conn   = Invoke-ADO "https://dev.azure.com/$Org/_apis/connectiondata"
    $userId = $conn.authenticatedUser.id
} catch {
    Write-Warning "Could not resolve user ID; filtering by email instead."
}

$apiBase = "https://dev.azure.com/$Org/$([Uri]::EscapeUriString($Project))/_apis"
$prQuery = if ($userId) {
    "$apiBase/git/pullrequests?searchCriteria.status=active&searchCriteria.creatorId=$userId&`$top=200&api-version=7.0"
} else {
    "$apiBase/git/pullrequests?searchCriteria.status=active&`$top=200&api-version=7.0"
}

$allPRs = @((Invoke-ADO $prQuery).value)
if (-not $userId) { $allPRs = @($allPRs | Where-Object { $_.createdBy.uniqueName -ieq $Email }) }

if ($allPRs.Count -eq 0) {
    Write-Host "No active PRs found for $Email. Nothing to send."
    exit 0
}

# ── Calculate aging ───────────────────────────────────────────────────────────
$today  = Get-Date
$prData = @(foreach ($pr in $allPRs) {
    $created   = [datetime]$pr.creationDate
    $daysOpen  = [math]::Floor(($today - $created).TotalDays)
    $daysLeft  = $AgingDays - $daysOpen
    $pctUsed   = [math]::Round(($daysOpen / $AgingDays) * 100)
    $repoName  = $pr.repository.name
    $urgency   = if    ($daysOpen -ge $AgingDays)              { "OVERDUE"  }   # >= 100%
                 elseif ($pctUsed -ge 90 -or $daysLeft -le 1) { "CRITICAL" }   # >= 90% OR <=1d left
                 elseif ($pctUsed -ge 75 -or $daysLeft -le 3) { "WARNING"  }   # >= 75% OR <=3d left
                 else                                          { "OK"       }
    [PSCustomObject]@{
        Id       = $pr.pullRequestId
        Title    = $pr.title
        Repo     = $repoName
        Created  = $created.ToString("yyyy-MM-dd")
        DaysOpen = $daysOpen
        DaysLeft = $daysLeft
        PctUsed  = $pctUsed
        Urgency  = $urgency
        Url      = "https://dev.azure.com/$Org/$([Uri]::EscapeUriString($Project))/_git/$repoName/pullrequest/$($pr.pullRequestId)"
    }
})
$prData = @($prData | Sort-Object {
    switch ($_.Urgency) { "OVERDUE"{0} "CRITICAL"{1} "WARNING"{2} default{3} }
}, DaysLeft)

$overdueCount  = @($prData | Where-Object Urgency -eq "OVERDUE").Count
$criticalCount = @($prData | Where-Object Urgency -eq "CRITICAL").Count
$warningCount  = @($prData | Where-Object Urgency -eq "WARNING").Count
$summaryParts  = @()
if ($overdueCount  -gt 0) { $summaryParts += "$overdueCount overdue (>100%)" }
if ($criticalCount -gt 0) { $summaryParts += "$criticalCount critical (>=90%)" }
if ($warningCount  -gt 0) { $summaryParts += "$warningCount warning (>=75%)" }
$summaryLine = if ($summaryParts.Count -gt 0) { $summaryParts -join "  |  " } else { "All within policy (<75%)" }

if ($DryRun) {
    Write-Host "=== DRY RUN ===" -ForegroundColor Cyan
    $prData | Format-Table Id, Title, Repo, Created, DaysOpen, DaysLeft, Urgency -AutoSize
    exit 0
}

# ══ TEAMS NOTIFICATION ════════════════════════════════════════════════════════
function Send-TeamsNotification {
    $emojiMap = @{ OVERDUE="🔴 OVERDUE"; CRITICAL="🟠 CRITICAL"; WARNING="🟡 WARNING"; OK="🟢 OK" }
    $colorMap = @{ OVERDUE="attention"; CRITICAL="warning"; WARNING="warning"; OK="good" }

    $rows = foreach ($pr in $prData) {
        $daysLabel = if ($pr.DaysLeft -lt 0)    { "$([math]::Abs($pr.DaysLeft))d overdue" }
                     elseif ($pr.DaysLeft -eq 0) { "Due today!" }
                     else                        { "$($pr.DaysLeft)d left" }
        $pctBar = [math]::Min($pr.PctUsed, 100)
        $progressText = "$($pr.PctUsed)% of $AgingDays-day limit used  ($($pr.DaysOpen)d open, $daysLabel)"
        @{
            type    = "ColumnSet"
            columns = @(
                @{
                    type  = "Column"; width = "auto"
                    items = @(@{
                        type   = "TextBlock"
                        text   = "$($emojiMap[$pr.Urgency])  $daysLabel"
                        color  = $colorMap[$pr.Urgency]
                        weight = "Bolder"
                        size   = "Small"
                    })
                },
                @{
                    type  = "Column"; width = "stretch"
                    items = @(
                        @{ type="TextBlock"; text="[$($pr.Title)]($($pr.Url))"; wrap=$true; weight="Bolder" },
                        @{ type="TextBlock"; text="Repo: $($pr.Repo)  |  Opened: $($pr.Created)  |  $($pr.PctUsed)% of $AgingDays-day limit used ($($pr.DaysOpen)d open)"; wrap=$true; spacing="None"; isSubtle=$true; size="Small" }
                    )
                }
            )
        }
    }

    $card = @{
        type        = "message"
        attachments = @(@{
            contentType = "application/vnd.microsoft.card.adaptive"
            contentUrl  = $null
            content     = @{
                "`$schema" = "http://adaptivecards.io/schemas/adaptive-card.json"
                type       = "AdaptiveCard"
                version    = "1.4"
                body       = @(
                    @{ type="TextBlock"; text="PR Aging Reminder - $(Get-Date -Format 'ddd MMM dd yyyy')"; weight="Bolder"; size="Large"; color="Accent" },
                    @{ type="TextBlock"; text="$($prData.Count) active PR(s)  |  Limit: $AgingDays days  |  $summaryLine"; wrap=$true; isSubtle=$true; spacing="Small" },
                    @{ type="Container"; separator=$true; spacing="Medium"; items=@($rows) },
                    @{ type="TextBlock"; text="$Email  |  $Org / $Project"; wrap=$true; isSubtle=$true; size="Small"; spacing="Medium" }
                )
            }
        })
    } | ConvertTo-Json -Depth 20 -Compress

    $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($card)
    $resp = Invoke-RestMethod -Uri $WebhookUrl -Method Post -Body $bodyBytes `
        -ContentType "application/json; charset=utf-8" -ErrorAction Stop
    Write-Host "Teams: sent ($($prData.Count) PR(s), response: $resp)"
}

# ══ EMAIL NOTIFICATION ════════════════════════════════════════════════════════
function Build-HtmlEmail {
    $urgencyStyle = @{
        OVERDUE  = "background:#c0392b;color:white;padding:2px 6px;border-radius:3px;font-size:11px;"
        CRITICAL = "background:#e67e22;color:white;padding:2px 6px;border-radius:3px;font-size:11px;"
        WARNING  = "background:#f1c40f;color:#333;padding:2px 6px;border-radius:3px;font-size:11px;"
        OK       = "background:#27ae60;color:white;padding:2px 6px;border-radius:3px;font-size:11px;"
    }

    $rows = foreach ($pr in $prData) {
        $daysLabel = if ($pr.DaysLeft -lt 0)    { "<strong style='color:#c0392b'>$([math]::Abs($pr.DaysLeft))d overdue</strong>" }
                     elseif ($pr.DaysLeft -eq 0) { "<strong style='color:#c0392b'>Due today!</strong>" }
                     else                         { "$($pr.DaysLeft)d left" }
        $badge = "<span style='$($urgencyStyle[$pr.Urgency])'>$($pr.Urgency)</span>"
        @"
        <tr style='border-bottom:1px solid #eee;'>
          <td style='padding:10px 8px;width:90px;'>$badge</td>
          <td style='padding:10px 8px;'>
            <a href='$($pr.Url)' style='color:#0078d4;font-weight:bold;text-decoration:none;'>$([System.Security.SecurityElement]::Escape($pr.Title))</a><br>
            <span style='color:#666;font-size:12px;'>$($pr.Repo) &nbsp;|&nbsp; Opened $($pr.Created) &nbsp;|&nbsp; $daysLabel</span>
          </td>
        </tr>
"@
    }

    return @"
<!DOCTYPE html><html><body style='font-family:Segoe UI,Arial,sans-serif;color:#333;max-width:700px;margin:0 auto;'>
  <div style='background:#0078d4;padding:16px 24px;border-radius:6px 6px 0 0;'>
    <h2 style='margin:0;color:white;font-size:18px;'>PR Aging Reminder</h2>
    <p style='margin:4px 0 0;color:#cce4f7;font-size:13px;'>$(Get-Date -Format 'dddd, MMMM dd yyyy')</p>
  </div>
  <div style='background:#f8f9fa;padding:12px 24px;border-left:1px solid #ddd;border-right:1px solid #ddd;'>
    <p style='margin:0;font-size:13px;color:#555;'>
      <strong>$($prData.Count)</strong> active PR(s) &nbsp;|&nbsp;
      Policy limit: <strong>$AgingDays days</strong> &nbsp;|&nbsp;
      $summaryLine
    </p>
  </div>
  <table style='width:100%;border-collapse:collapse;border:1px solid #ddd;border-top:none;'>
    $($rows -join "`n")
  </table>
  <div style='background:#f8f9fa;padding:10px 24px;border:1px solid #ddd;border-top:none;border-radius:0 0 6px 6px;'>
    <p style='margin:0;font-size:11px;color:#999;'>$Email &nbsp;|&nbsp; $Org / $Project &nbsp;|&nbsp; Sent by PR Aging Reminder</p>
  </div>
</body></html>
"@
}

# ══ Dispatch ══════════════════════════════════════════════════════════════════
$sent = 0
if (-not [string]::IsNullOrWhiteSpace($WebhookUrl)) {
    try   { Send-TeamsNotification; $sent++ }
    catch { Write-Warning "Teams notification failed: $_" }
}
if ($sent -eq 0) {
    Write-Warning "No notifications sent. Re-run Install.ps1 to reconfigure."
}
